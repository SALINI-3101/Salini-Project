<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sustainability";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

           
				$nam=$_POST['name'];
            $mai=$_POST['email'];
$sql = "INSERT INTO health (name,email) VALUES ('$nam', '$mai')";
            if ($conn->query($sql) === TRUE) {
				echo '<script>alert("Message sent is Successfull");
window.location.href="dashboard.html";
</script>';
               
            } 
			else {
                echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?> 	   