<?php  
 require('db_connect.php');

if (isset($_POST['email']) and isset($_POST['pass2'])){
	
// Assigning POST values to variables.
$username = $_POST['email'];
$password2 = $_POST['pass2'];
$pass3=md5($password2);
// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `user` WHERE email='$username' and password='$pass3'";
 
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);

if($count!=1)
{
echo '<script>alert("You have no account please signup");
window.location.href="admin.html";

</script>';

}

elseif ($count == 1){

include 'dashboard.html';
}
else{
echo '<script>alert("Incorrect password");
window.location.href="admin.html";

</script>';
}
}
?>