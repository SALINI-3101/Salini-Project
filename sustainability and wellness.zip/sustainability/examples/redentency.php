<pre>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "latecomer";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


            $mail = $_POST['email'];
            $passw = $_POST['pass2'];
			$password1=md5($passw);
//require_once('duplicate.php');
$sql= "SELECT * FROM signup WHERE email = '$mail' ";
$result = mysqli_query($conn,$sql);
$check = mysqli_fetch_array($result);
if($mail!=$check['email'])
{
echo '<script>alert("You have no account please signup");
window.location.href="admin.html";

</script>';

}
else{
	  $mail = $_POST['email'];
	 $passw = $_POST['pass2'];
	$password1=md5($passw);
	echo"$mail";
	echo"$passw";
$sql= "SELECT * FROM signup WHERE (email='$mail' and password ='$password1')";
$result = mysqli_query($conn,$sql);
$check = mysqli_num_rows($result);
echo"$check";
if($check==1)
{
	include 'adminnext.html';
	
}
else{
	
	echo '<script>alert("Incorrect password");
window.location.href="admin.html";

</script>';

}
}
?>